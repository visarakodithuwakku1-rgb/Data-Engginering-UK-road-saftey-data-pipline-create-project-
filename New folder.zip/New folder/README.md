# 5DATA005C — UK Road Safety Data Pipeline (VS Code)

**Run full pipeline locally**
```bash
pip install -r requirements.txt
python src/pipeline.py
```

**What you'll get (full run):**
- Processed CSVs in `data/processed/`
- Star schema dims/fact CSVs
- SQLite DB at `db/accidents.db`
- Charts in `docs/figures/`
- EDA summaries in `docs/`

This zip already contains a *sample* SQLite (`db/accidents_sample.db`) and a short PDF.