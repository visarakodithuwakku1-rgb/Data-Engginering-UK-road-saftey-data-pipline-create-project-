
# Purpose: bring in libraries and set base paths used everywhere
import os
import sqlite3
from datetime import datetime

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

BASE_DIR = os.path.dirname(os.path.dirname(__file__))   # project root
RAW_DIR  = os.path.join(BASE_DIR, "data", "raw")
PROC_DIR = os.path.join(BASE_DIR, "data", "processed")
DOCS_DIR = os.path.join(BASE_DIR, "docs")
FIG_DIR  = os.path.join(DOCS_DIR, "figures")
DB_DIR   = os.path.join(BASE_DIR, "db")

for d in [PROC_DIR, FIG_DIR, DB_DIR]:
    os.makedirs(d, exist_ok=True)



# Purpose: small utilities used across steps

def find_col(cols, candidates):
    """Return the first existing column (case-insensitive) from a list of candidates."""
    m = {c.lower(): c for c in cols}
    for cand in candidates:
        if cand.lower() in m:
            return m[cand.lower()]
    return None

def save_txt(lines, path):
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

def monthly_counts(df, dt_col):
    ts = df[dt_col].dropna().dt.to_period("M").dt.to_timestamp()
    return ts.value_counts().sort_index()


# LOAD RAW DATA 
# Purpose: read the 3 datasets (collisions, vehicles, casualties)

def load_raw():
    paths = {
        "collisions": os.path.join(RAW_DIR, "dft-road-casualty-statistics-collision-last-5-years.csv"),
        "vehicles":   os.path.join(RAW_DIR, "dft-road-casualty-statistics-vehicle-last-5-years.csv"),
        "casualties": os.path.join(RAW_DIR, "dft-road-casualty-statistics-casualty-last-5-years.csv"),
    }
    dfs = {}
    for k, p in paths.items():
        df = pd.read_csv(p, low_memory=False)
        df.columns = [str(c) for c in df.columns]
        dfs[k] = df
    return dfs



#  EXPLORATION / EDA 
# Purpose: basic shapes, dtypes, missing %, summaries saved to /docs

def run_eda(dfs):
    lines = [f"EDA generated: {datetime.now():%Y-%m-%d %H:%M:%S}", ""]
    for name, df in dfs.items():
        r, c = df.shape
        lines += [f"=== {name.upper()} ===", f"rows={r}, cols={c}"]

        # dtypes
        dtypes_path = os.path.join(DOCS_DIR, f"{name}_dtypes.csv")
        df.dtypes.astype(str).to_csv(dtypes_path, header=["dtype"])

        # missing
        miss = df.isna().sum()
        miss_pct = (miss / max(len(df), 1) * 100).round(2)
        pd.DataFrame({"missing": miss, "missing_pct": miss_pct}).to_csv(
            os.path.join(DOCS_DIR, f"{name}_missing.csv")
        )

        # numeric / categorical describe
        df.select_dtypes(include=[np.number]).describe(include="all").T.to_csv(
            os.path.join(DOCS_DIR, f"{name}_desc_numeric.csv")
        )
        df.select_dtypes(exclude=[np.number]).describe(include="all").T.to_csv(
            os.path.join(DOCS_DIR, f"{name}_desc_categorical.csv")
        )
        lines.append("")

    save_txt(lines, os.path.join(DOCS_DIR, "eda_summary.txt"))



#VISUALISATIONS 
# Purpose: matplotlib-only charts saved to /docs/figures

def make_figures(dfs):
    # Collisions: monthly trend
    col = dfs["collisions"].copy()
    date_col = find_col(col.columns, ["Date", "date", "Accident_Date"])
    if date_col:
        col["_dt"] = pd.to_datetime(col[date_col], errors="coerce")
        s = monthly_counts(col, "_dt")
        if len(s) > 0:
            fig = plt.figure(figsize=(9, 3))
            plt.plot(s.index, s.values)
            plt.title("Collisions per month")
            plt.xlabel("Month")
            plt.ylabel("Count")
            fig.tight_layout()
            fig.savefig(os.path.join(FIG_DIR, "collisions_trend.png"), dpi=150, bbox_inches="tight")
            plt.close(fig)

    # Vehicles: correlation heatmap (numeric only)
    veh = dfs["vehicles"].select_dtypes(include=[np.number])
    if veh.shape[1] >= 2:
        corr = veh.corr(numeric_only=True)
        fig = plt.figure(figsize=(6, 5))
        plt.imshow(corr, aspect="auto")
        plt.xticks(range(len(corr.columns)), corr.columns, rotation=90, fontsize=7)
        plt.yticks(range(len(corr.columns)), corr.columns, fontsize=7)
        plt.title("Vehicles: correlation (numeric)")
        plt.colorbar()
        fig.tight_layout()
        fig.savefig(os.path.join(FIG_DIR, "vehicles_corr.png"), dpi=150, bbox_inches="tight")
        plt.close(fig)

    #  Casualties: severity distribution
    cas = dfs["casualties"].copy()
    sev_col = find_col(cas.columns, ["Casualty_Severity", "casualty_severity"])
    if sev_col:
        counts = cas[sev_col].astype(str).value_counts().head(12)
        if len(counts) > 0:
            fig = plt.figure(figsize=(8, 3))
            plt.bar(counts.index, counts.values)
            plt.title("Casualty severity distribution")
            plt.xticks(rotation=45, ha="right")
            plt.ylabel("Count")
            fig.tight_layout()
            fig.savefig(os.path.join(FIG_DIR, "casualties_severity.png"), dpi=150, bbox_inches="tight")
            plt.close(fig)



# CLEANING & FEATURE ENGINEERING 
# Purpose: simple bounds/encodings and time features; saves *_processed.csv

def clean_and_engineer(dfs):
    proc = {}

    # Collisions
    c = dfs["collisions"].copy()
    aidx = find_col(c.columns, ["Accident_Index", "accident_index"])
    dcol = find_col(c.columns, ["Date", "date", "Accident_Date"])
    if dcol:
        c["_dt"] = pd.to_datetime(c[dcol], errors="coerce")
        c["acc_year"] = c["_dt"].dt.year
        c["acc_month"] = c["_dt"].dt.month
        c["is_weekend"] = c["_dt"].dt.dayofweek >= 5
    if aidx:
        c = c.drop_duplicates(subset=[aidx])
    proc["collisions"] = c

    # Vehicles
    v = dfs["vehicles"].copy()
    age_driver = find_col(v.columns, ["Age_of_Driver", "age_of_driver"])
    if age_driver:
        v[age_driver] = pd.to_numeric(v[age_driver], errors="coerce")
        v.loc[(v[age_driver] < 0) | (v[age_driver] > 100), age_driver] = np.nan
        v[age_driver] = v[age_driver].fillna(v[age_driver].median())
    proc["vehicles"] = v

    # Casualties
    s = dfs["casualties"].copy()
    age_cas = find_col(s.columns, ["Age_of_Casualty", "age_of_casualty", "Age"])
    if age_cas:
        s[age_cas] = pd.to_numeric(s[age_cas], errors="coerce")
        s.loc[(s[age_cas] < 0) | (s[age_cas] > 110), age_cas] = np.nan
        s[age_cas] = s[age_cas].fillna(s[age_cas].median())
    proc["casualties"] = s

    # write processed CSVs
    for name, df in proc.items():
        df.to_csv(os.path.join(PROC_DIR, f"{name}_processed.csv"), index=False)

    return proc


# STAR SCHEMA BUILD 
# Purpose: create DimTime, DimCollision, DimVehicle, DimCasualty, FactAccident

def build_star(proc):
    #  DimTime
    dim_time = pd.DataFrame()
    if "collisions" in proc and "_dt" in proc["collisions"].columns:
        t = proc["collisions"][["_dt"]].dropna().drop_duplicates().sort_values(by=["_dt"]).copy()
        t["date"] = t["_dt"].dt.date.astype(str)
        t["year"] = t["_dt"].dt.year
        t["quarter"] = t["_dt"].dt.quarter
        t["month"] = t["_dt"].dt.month
        t["day"] = t["_dt"].dt.day
        t["dow"] = t["_dt"].dt.dayofweek
        t["time_key"] = range(1, len(t) + 1)
        dim_time = t[["time_key", "date", "year", "quarter", "month", "day", "dow"]]
    dim_time.to_csv(os.path.join(PROC_DIR, "dim_time.csv"), index=False)

    #  DimCollision
    c = proc["collisions"].copy()
    c["collision_key"] = range(1, len(c) + 1)
    aidx_c = find_col(c.columns, ["Accident_Index", "accident_index"])
    dcol   = find_col(c.columns, ["Date", "date", "Accident_Date"])
    sev_c  = find_col(c.columns, ["Accident_Severity", "accident_severity"])
    lat_c  = find_col(c.columns, ["Latitude", "latitude"])
    lon_c  = find_col(c.columns, ["Longitude", "longitude"])
    if not dim_time.empty and "_dt" in c.columns:
        m = dim_time.set_index("date")["time_key"]
        c["date_str"] = c["_dt"].dt.date.astype(str)
        c["time_key"] = c["date_str"].map(m)
    keep = ["collision_key"]
    for col in [aidx_c, dcol, sev_c, lat_c, lon_c, "time_key"]:
        if (col in c.columns) or (col == "time_key"):
            keep.append(col)
    dim_collision = c[keep].copy()
    dim_collision.to_csv(os.path.join(PROC_DIR, "dim_collision.csv"), index=False)

    # DimVehicle
    v = proc["vehicles"].copy()
    v["vehicle_key"] = range(1, len(v) + 1)
    aidx_v = find_col(v.columns, ["Accident_Index", "accident_index"])
    vtype  = find_col(v.columns, ["Vehicle_Type", "vehicle_type"])
    age_driver = find_col(v.columns, ["Age_of_Driver", "age_of_driver"])
    keepv = ["vehicle_key"]
    for col in [aidx_v, vtype, age_driver]:
        if col in v.columns:
            keepv.append(col)
    dim_vehicle = v[keepv].copy()
    dim_vehicle.to_csv(os.path.join(PROC_DIR, "dim_vehicle.csv"), index=False)

    #  DimCasualty
    s = proc["casualties"].copy()
    s["casualty_key"] = range(1, len(s) + 1)
    aidx_s = find_col(s.columns, ["Accident_Index", "accident_index"])
    sev_s  = find_col(s.columns, ["Casualty_Severity", "casualty_severity"])
    cls_s  = find_col(s.columns, ["Casualty_Class", "casualty_class"])
    age_cas= find_col(s.columns, ["Age_of_Casualty", "age_of_casualty", "Age"])
    keeps = ["casualty_key"]
    for col in [aidx_s, sev_s, age_cas, cls_s]:
        if col in s.columns:
            keeps.append(col)
    dim_casualty = s[keeps].copy()
    dim_casualty.to_csv(os.path.join(PROC_DIR, "dim_casualty.csv"), index=False)

    # FactAccident (join on Accident_Index)
    fact = pd.DataFrame()
    if aidx_c and (aidx_c in dim_collision.columns):
        base = dim_collision[[c for c in dim_collision.columns if c in ["collision_key", aidx_c, "time_key"]]].copy()
        if aidx_v and (aidx_v in dim_vehicle.columns):
            veh_first = dim_vehicle.groupby(aidx_v)["vehicle_key"].first().reset_index()
            base = base.merge(veh_first, on=aidx_c, how="left")
        if aidx_s and (aidx_s in dim_casualty.columns):
            cas_first = dim_casualty.groupby(aidx_s)["casualty_key"].first().reset_index()
            base = base.merge(cas_first, on=aidx_c, how="left")
        if sev_c and (sev_c in dim_collision.columns):
            base = base.merge(dim_collision[[aidx_c, sev_c]].drop_duplicates(), on=aidx_c, how="left")
        base["fact_key"] = range(1, len(base) + 1)
        keepf = ["fact_key", "collision_key", "time_key"]
        for col in ["vehicle_key", "casualty_key", sev_c]:
            if col in base.columns and col not in keepf:
                keepf.append(col)
        fact = base[keepf].copy()

    # ensure table exists even if empty
    if fact.empty:
        fact = pd.DataFrame(columns=["fact_key", "collision_key", "time_key", "vehicle_key", "casualty_key", "Accident_Severity"])
    fact.to_csv(os.path.join(PROC_DIR, "fact_accident.csv"), index=False)

    return dim_time, dim_collision, dim_vehicle, dim_casualty, fact



# LOAD INTO SQLITE
# Purpose: create tables and load the star schema into a DB

def load_sqlite():
    db_path = os.path.join(DB_DIR, "accidents.db")
    conn = sqlite3.connect(db_path)
    with conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS dim_time (
            time_key INTEGER PRIMARY KEY, date TEXT, year INTEGER, quarter INTEGER,
            month INTEGER, day INTEGER, dow INTEGER)""")
        conn.execute("""CREATE TABLE IF NOT EXISTS dim_collision (
            collision_key INTEGER PRIMARY KEY, Accident_Index TEXT, Date TEXT,
            Accident_Severity TEXT, Latitude REAL, Longitude REAL, time_key INTEGER)""")
        conn.execute("""CREATE TABLE IF NOT EXISTS dim_vehicle (
            vehicle_key INTEGER PRIMARY KEY, Accident_Index TEXT, Vehicle_Type TEXT, Age_of_Driver REAL)""")
        conn.execute("""CREATE TABLE IF NOT EXISTS dim_casualty (
            casualty_key INTEGER PRIMARY KEY, Accident_Index TEXT, Casualty_Severity TEXT,
            Age_of_Casualty REAL, Casualty_Class TEXT)""")
        conn.execute("""CREATE TABLE IF NOT EXISTS fact_accident (
            fact_key INTEGER PRIMARY KEY, collision_key INTEGER, time_key INTEGER,
            vehicle_key INTEGER, casualty_key INTEGER, Accident_Severity TEXT)""")

        # load CSVs into DB
        pd.read_csv(os.path.join(PROC_DIR, "dim_time.csv")).to_sql("dim_time", conn, if_exists="replace", index=False)
        pd.read_csv(os.path.join(PROC_DIR, "dim_collision.csv")).to_sql("dim_collision", conn, if_exists="replace", index=False)
        pd.read_csv(os.path.join(PROC_DIR, "dim_vehicle.csv")).to_sql("dim_vehicle", conn, if_exists="replace", index=False)
        pd.read_csv(os.path.join(PROC_DIR, "dim_casualty.csv")).to_sql("dim_casualty", conn, if_exists="replace", index=False)
        pd.read_csv(os.path.join(PROC_DIR, "fact_accident.csv")).to_sql("fact_accident", conn, if_exists="replace", index=False)
    return db_path



# Writes PASS/WARN/FAIL lines to docs/tests_report.txt

def run_tests(dfs, proc, db_path):
    lines = []
    ok = True

    #  6.a Data loader tests 
    # a.i) raw files can be loaded successfully
    for name in ("collisions", "vehicles", "casualties"):
        try:
            df = dfs[name]
            loaded = isinstance(df, pd.DataFrame) and df.shape[1] > 0
        except Exception:
            loaded = False
        lines.append(f"[{'PASS' if loaded else 'FAIL'}] 6.a.i raw load: {name} "
                     f"(rows={df.shape[0] if loaded else 'NA'}, cols={df.shape[1] if loaded else 'NA'})")
        ok &= loaded

    # a.ii) expected key columns are present
    EXPECT = {
        "collisions": [
            ["Date", "Accident_Date", "date"],            # a date exist
            # NOTE: Accident_Index is OPTIONAL in this dataset
        ],
        "vehicles": [
            ["Vehicle_Type", "vehicle_type"],
            ["Age_of_Driver", "age_of_driver"],
        ],
        "casualties": [
            ["Casualty_Severity", "casualty_severity"],
            ["Age_of_Casualty", "age_of_casualty", "Age"],
            ["Casualty_Class", "casualty_class"],
        ],
    }
        
    for name, groups in EXPECT.items():
        df = dfs[name]
        present = all(find_col(df.columns, g) for g in groups)
        missing_groups = ["/".join(g) for g in groups if not find_col(df.columns, g)]
        lines.append(f"[{'PASS' if present else 'FAIL'}] 6.a.ii expected columns in {name}: "
                     f"{'OK' if present else 'missing -> ' + ', '.join(missing_groups)}")
        ok &= present

    #  6.b Transformation tests 
    # b.i) cleaning rules applied (no negative ages after cleaning)
    v = proc.get("vehicles", pd.DataFrame()).copy()
    s = proc.get("casualties", pd.DataFrame()).copy()

    age_driver = find_col(v.columns, ["Age_of_Driver", "age_of_driver"])
    if age_driver:
        bad = v[age_driver].dropna().lt(0).sum()
        lines.append(f"[{'PASS' if bad == 0 else 'FAIL'}] 6.b.i driver age >= 0 (bad={bad})")
        ok &= (bad == 0)

    age_cas = find_col(s.columns, ["Age_of_Casualty", "age_of_casualty", "Age"])
    if age_cas:
        bad = s[age_cas].dropna().lt(0).sum()
        lines.append(f"[{'PASS' if bad == 0 else 'FAIL'}] 6.b.i casualty age >= 0 (bad={bad})")
        ok &= (bad == 0)

    # b.ii) encoded categorical columns have expected categories (severity)
    sev_cas = find_col(s.columns, ["Casualty_Severity", "casualty_severity"])
    if sev_cas:
        allowed = {"Fatal", "Serious", "Slight"}
        values = set(s[sev_cas].dropna().astype(str).unique())
        extras = sorted(values - allowed)
        state = "PASS" if not extras else "WARN"
        lines.append(f"[{state}] 6.b.ii casualty severity within {sorted(allowed)}; "
                     f"extras={extras if extras else 'None'}")
        # (WARN does not flip the global ok flag)

    #  6.c Serving / loading tests 
    # c.i) transformed data can be inserted into DB (dry-run insert + rollback)
    try:
        conn = sqlite3.connect(db_path)
        with conn:
            conn.execute("BEGIN")
            conn.execute("""INSERT INTO dim_time (time_key, date, year, quarter, month, day, dow)
                            VALUES (999999, '2099-01-01', 2099, 1, 1, 1, 1)""")
            conn.rollback()  # do not leave test data
        lines.append("[PASS] 6.c.i can insert into DB (transaction rolled back)")
    except Exception as e:
        lines.append(f"[FAIL] 6.c.i insert test failed: {e}")
        ok = False
    finally:
        try:
            conn.close()
        except Exception:
            pass

    # c.ii) fact and dimension tables contain data after loading
    try:
        conn = sqlite3.connect(db_path)
        with conn:
            for t in ["dim_time", "dim_collision", "dim_vehicle", "dim_casualty", "fact_accident"]:
                n = conn.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
                lines.append(f"[{'PASS' if n >= 0 else 'FAIL'}] 6.c.ii table {t} rows={n}")
                ok &= (n >= 0)
    except Exception as e:
        lines.append(f"[FAIL] 6.c.ii DB read failed: {e}")
        ok = False
    finally:
        try:
            conn.close()
        except Exception:
            pass

    # Also keep the simple processed-file existence check
    for name in ["collisions", "vehicles", "casualties"]:
        fp = os.path.join(PROC_DIR, f"{name}_processed.csv")
        exists = os.path.exists(fp) and os.path.getsize(fp) > 0
        lines.append(f"[{'PASS' if exists else 'FAIL'}] processed CSV exists: {fp}")
        ok &= exists

    # Write report
    os.makedirs(DOCS_DIR, exist_ok=True)
    with open(os.path.join(DOCS_DIR, "tests_report.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    return ok


# MAIN (orchestration)

def main():
    print("Loading raw CSVs...")
    dfs = load_raw()

    print("Running EDA...")
    run_eda(dfs)

    print("Creating figures...")
    make_figures(dfs)

    print("Cleaning & feature engineering...")
    proc = clean_and_engineer(dfs)

    print("Building star schema...")
    build_star(proc)

    print("Loading into SQLite...")
    db_path = load_sqlite()

    print("Running tests...")
    ok = run_tests(dfs, proc, db_path)   # <-- expanded tests signature
    print("Done. Success =", ok, "| SQLite DB:", db_path)

if __name__ == "__main__":
    main()




